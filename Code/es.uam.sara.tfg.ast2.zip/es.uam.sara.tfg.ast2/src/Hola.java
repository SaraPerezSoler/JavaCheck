
public enum Hola {
	Casa(0), Hotel(1);
	int i;
	private Hola (int i){
		this.i=i;
	}
}
