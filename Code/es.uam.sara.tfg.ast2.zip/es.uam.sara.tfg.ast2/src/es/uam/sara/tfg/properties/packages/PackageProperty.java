
package es.uam.sara.tfg.properties.packages;

import es.uam.sara.tfg.elements.Package;
import es.uam.sara.tfg.properties.Properties;


public abstract class PackageProperty extends Properties<Package> {

	public PackageProperty() {
		super();
	}
}
