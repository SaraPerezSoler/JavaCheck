
package es.uam.sara.tfg.properties.attributes;

import es.uam.sara.tfg.elements.Attribute;
import es.uam.sara.tfg.properties.Properties;


public abstract class AttributeProperty extends Properties<Attribute> {

	public AttributeProperty() {
	}
}
