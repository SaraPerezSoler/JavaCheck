/**
 * 
 */
package es.uam.sara.tfg.properties.methods;

import es.uam.sara.tfg.elements.Method;
import es.uam.sara.tfg.properties.Properties;


/**
 * @author Sara
 *
 */
public abstract class MethodProperty extends Properties<Method> {

	public MethodProperty() {
		super();
	}
}
