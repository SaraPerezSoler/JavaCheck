package es.uam.sara.tfg.properties.interfaces;

import es.uam.sara.tfg.elements.ClassInterface;
import es.uam.sara.tfg.properties.Properties;


public abstract class InterfaceProperty extends Properties<ClassInterface> {

	public InterfaceProperty() {
		super();
	}
	
}
