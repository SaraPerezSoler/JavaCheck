package es.uam.sara.tfg.properties.annotations;

import org.eclipse.jdt.core.dom.AnnotationTypeDeclaration;

import es.uam.sara.tfg.properties.Properties;

public abstract class  AnnotationDeclaration extends Properties<AnnotationTypeDeclaration>{

}
