package es.uam.sara.tfg.properties.enumconstant;

import org.eclipse.jdt.core.dom.EnumConstantDeclaration;

import es.uam.sara.tfg.properties.Properties;

public abstract class EnumConstant extends Properties<EnumConstantDeclaration>{


}
