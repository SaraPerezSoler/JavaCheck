package es.uam.sara.tfg.properties;

public class PropertiesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PropertiesException(String msg) {
		super(msg);
	}

}
