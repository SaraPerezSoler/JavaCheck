package es.uam.sara.tfg.properties.file;

import es.uam.sara.tfg.elements.File;
import es.uam.sara.tfg.properties.Properties;

public abstract class FileProperty extends Properties<File>{


}
