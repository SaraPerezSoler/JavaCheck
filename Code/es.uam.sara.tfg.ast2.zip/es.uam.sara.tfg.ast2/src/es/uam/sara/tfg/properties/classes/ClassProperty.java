package es.uam.sara.tfg.properties.classes;

import es.uam.sara.tfg.elements.ClassInterface;
import es.uam.sara.tfg.properties.Properties;


public abstract class ClassProperty extends Properties<ClassInterface> {

	public ClassProperty() {
		super();
	}
}
