package es.uam.sara.tfg.properties;

public interface StringProperty {

	
}
