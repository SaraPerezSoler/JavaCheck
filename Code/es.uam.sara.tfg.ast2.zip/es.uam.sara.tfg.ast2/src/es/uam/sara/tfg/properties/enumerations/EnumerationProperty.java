package es.uam.sara.tfg.properties.enumerations;

import es.uam.sara.tfg.elements.Enumeration;
import es.uam.sara.tfg.properties.Properties;


public abstract class EnumerationProperty extends Properties<Enumeration> {

	public EnumerationProperty() {
		super();
	}

}
